#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"tabelasimb.h"
int main(){
	struct tbs * tb1;
	struct tbs * tb2;
	struct elemVar params[100];
	tb1 = iniciarTabelaSim(NULL);
	insereVar(tb1,"var1",INT,0);
	insereVar(tb1,"var2",CAR,1);
	insereVar(tb1,"var3",INT,2);
	insereVar(tb1,"var4",CAR,3);
	insereVar(tb1,"var5",CAR,4);
	insereVar(tb1,"var6",INT,5);
	printf("Variaveis no escopo 1 : %s %s %s %s %s %s\n",tb1->elems[0].nome,tb1->elems[1].nome,tb1->elems[2].nome,tb1->elems[3].nome,tb1->elems[4].nome,tb1->elems[5].nome);
	criaParametro(params,"p1",0,INT);
	criaParametro(params,"p2",1,INT);
	criaParametro(params,"p3",2,INT);
	insereFun(tb1,"f1",INT,3,params,0);
	printf("Funcao e parametros de funcao do escopo 1 : %s %s %s %s\n",tb1->elemsf[0].nomeF,tb1->elemsf[0].param[0].nome,tb1->elemsf[0].param[1].nome,tb1->elemsf[0].param[2].nome);
	novoEscopo(tb1);
	insereVar(tb1->filho,"var0",CAR,0);
	printf("Variavel no filho do escopo 1 : %s\n",tb1->filho->elems[0].nome);
	tb2 = busca(tb1,"var0");
	printf("Variavel encontrada no escopo atual : %s\n",tb2->elems[0].nome);
	removeEscopo(tb1);
	desalocaTabela(tb1);
return 0;
}
