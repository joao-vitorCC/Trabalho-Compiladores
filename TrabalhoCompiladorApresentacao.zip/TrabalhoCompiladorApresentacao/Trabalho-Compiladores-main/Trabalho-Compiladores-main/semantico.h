#ifndef SEMANTICO
# define SEMANTICO
#endif
void percorreAst(struct no *n);
int identificaTipo(char str[]);
void analise(struct no *n);
int verifica_expr(struct no *node);
void insereParam(struct no *n,struct elemVar Parametros[100],int * qtd);
int buscaP(struct elemVar Parametros[100],char val[] );
int vParam(struct no *n,struct elemVar Parametros[100]);
void vTbs(struct tbs * tb);
