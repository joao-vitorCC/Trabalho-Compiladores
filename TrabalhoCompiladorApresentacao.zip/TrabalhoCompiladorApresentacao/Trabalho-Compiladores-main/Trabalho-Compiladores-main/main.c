#include<stdio.h>
#include<stdlib.h>
#include"ast.h"
#include"tabelasimb.h"
#include"semantico.h"
#include<string.h>
extern int yylex();
extern FILE *yyin;
extern void yyerror(char const *);
extern int yylineno;
extern char * yytext;
extern struct no * ast;
extern int yyparse();

struct  tbs * tb;

int p = 0;
int f = 0;
int esc=0;

int main(int argc, char**argv){
     if(argc!=2){
          printf("Uso correto: goianinha <nome> \n");
          exit(1);
     }
     yyin=fopen(argv[1],"rt");
     if(yyin){
        int r = yyparse();
        if(r != 1){
        	tb = iniciarTabelaSim(NULL);
    		percorreAst(ast);
			printf("----------------");
			printf("----------------");
			printf("----------------");
    		analise(ast);
			printf("----------------");
			printf("----------------");
			printf("----------------");
    		verifica_expr(ast);
			printf("----------------");
			printf("----------------");
			printf("----------------");
			//vTbs(tb);
        }
     }   
     else 
          yyerror("arquivo nao encontrado");
     return(1);
}



