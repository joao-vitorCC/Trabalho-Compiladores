#!/bin/bash
	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
    echo "Teste fatorialErroLin3NomeDeclaradoNoMesmoEscopo"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha fatorialErroLin3NomeDeclaradoNoMesmoEscopo.g	

	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
    echo "Teste fatorialErroLin5TipoRetornado.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha fatorialErroLin5TipoRetornado.g

	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
	echo "Teste FibEfatErroCarEIntNaEprLin8.g"
	echo "-----------------------"
	echo "-----------------------"
	echo -e "-----------------------\\n"
    ./goianinha FibEfatErroCarEIntNaEprLin8.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FibEfatErroTIposDiferentesExpEnquntoLin30.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FibEfatErroTIposDiferentesExpEnquntoLin30.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FibEfatVersao2ErroAtribuicaoVarDeTipoDiferenteDaExpressaoLin22.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FibEfatVersao2ErroAtribuicaoVarDeTipoDiferenteDaExpressaoLin22.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FuncSomaErroNumParamDeChamaaDifNumParamFormal.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FuncSomaErroNumParamDeChamaaDifNumParamFormal.g

	echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FuncSomaErroParamDeChamaaDifDoParamFormalLin10.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FuncSomaErroParamDeChamaaDifDoParamFormalLin10.g




