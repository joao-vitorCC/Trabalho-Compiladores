#!/bin/bash
	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
    echo "Teste erroLin6AsteriscoAmais"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha erroLin6AsteriscoAmais.g	

	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
    echo "Teste erroLin6Caractereinvalido.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha erroLin6Caractereinvalido.g

	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
	echo "Teste expressao1ErroLin4CadeiaNaoTermina.g"
	echo "-----------------------"
	echo "-----------------------"
	echo -e "-----------------------\\n"
    ./goianinha expressao1ErroLin4CadeiaNaoTermina.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste expressao1ErroLin4PontoVirg.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha expressao1ErroLin4PontoVirg.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste fatorialErroLin15String2linhas.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha fatorialErroLin15String2linhas.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FibEfatErroBlocoEnquantoNaoTerminaLin30.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FibEfatErroBlocoEnquantoNaoTerminaLin30.g

	echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste NotaEmConceitoErroSenaoSemSeLin25.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha NotaEmConceitoErroSenaoSemSeLin25.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste sintatico_fatorialErroLin1Comentario.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha sintatico_fatorialErroLin1Comentario.g

	echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste string_multilinha.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha string_multilinha.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste testeSintaticoErrados.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha testeSintaticoErrados.g



