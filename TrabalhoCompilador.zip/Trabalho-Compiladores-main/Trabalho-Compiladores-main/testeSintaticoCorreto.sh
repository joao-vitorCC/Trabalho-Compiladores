#!/bin/bash
	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
    echo "Teste fatorialCorreto.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha fatorialCorreto.g

	echo -e "\\n-----------------------"
	echo "-----------------------"
	echo "-----------------------"
	echo "Teste FibEfatCorreto.g"
	echo "-----------------------"
	echo "-----------------------"
	echo -e "-----------------------\\n"
    ./goianinha FibEfatCorreto.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste FibEfatCorretoVersao2.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha FibEfatCorretoVersao2.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste NotaEmConceito.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha NotaEmConceito.g
    
    echo -e "\\n-----------------------"
    echo "-----------------------"
    echo "-----------------------"
    echo "Teste SeqOrdenada.g"
    echo "-----------------------"
    echo "-----------------------"
    echo -e "-----------------------\\n"
    ./goianinha SeqOrdenada.g
